import os

import discord
from discord.ext import commands
from discord.ext.commands import when_mentioned_or
from tools.autocogs import AutoCogs
from dotenv import load_dotenv
load_dotenv(verbose=True)


class MyBot(commands.Bot):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        AutoCogs(self)
        self.remove_command("help")
    async def on_ready(self):
        await self.change_presence(status=discord.Status.online,
                                   activity=discord.Activity(name="!도움",
                                                             type=discord.ActivityType.playing))
        print("Bot is ready.")


INTENTS = discord.Intents.all()
my_bot = MyBot(command_prefix='!', intents=INTENTS)


if __name__ == "__main__":
    my_bot.run(os.getenv('DISCORD_BOT_TOKEN'))