from discord.ext import commands
from config import OWNERS
from tools.autocogs import AutoCogsReload
def is_owner():
    async def predicate(ctx):
        return ctx.author.id in OWNERS

    return commands.check(predicate)
class owner(commands.Cog):
    def __init__(self,bot):
        self.bot = bot


    @commands.command(name="reload", aliases=["리로드", "r"])
    @is_owner()
    async def 리로드(self, ctx, extension=None):
        if extension is None:  # extension이 None이면 (그냥 !리로드 라고 썼을 때)
            try:
                AutoCogsReload(self.bot)
                await ctx.send(f"모든 모듈을 리로드했어요.")
            except Exception as a:
                await ctx.send(f"리로드에 실패했어요. [{a}]")
        else:
            try:
                self.bot.unload_extension(f"cogs.{extension}")
                self.bot.load_extension(f"cogs.{extension}")
                await ctx.send(f":white_check_mark: `{extension}`을(를) 다시 불러왔습니다!")
            except Exception as a:
                await ctx.send(f"[{extension}]모듈을 리로드도중 에러가 발생했습니다.```{a}```")

def setup(bot):
    bot.add_cog(owner(bot))
    print('cogs - `owner` is loaded')