import os

import discord
from discord.ext import commands
from pysondb import db
from dotenv import load_dotenv
load_dotenv(verbose=True)


class admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="경고")
    @commands.has_permissions(administrator=True)
    async def warn(self,ctx,user:discord.Member,*,reason="사유없음"):
        a = db.getDb(os.getenv("DB_LOCATION"))
        ID = a.add({"user_name":user.display_name,
               "user_id":user.id,
               "reason":reason})
        count = a.getBy({"user_id":user.id})
        num = 0
        for i in count:
            num += 1
        em = discord.Embed(title="🚨 경고 로그🚨", colour=discord.Colour.red())
        em.add_field(name="👮‍♂️경고 요청자", value=f"{ctx.author.mention}", inline=False)
        em.add_field(name="📌경고 대상자", value=f"{user.mention}", inline=False)
        em.add_field(name="경고 횟수", value=f"`{num}` 회", inline=False)
        em.add_field(name="사유", value=reason, inline=False)
        em.set_footer(text=f"경고ID - {ID}",icon_url=user.avatar_url)
        await ctx.reply(embed=em)

    @commands.command(name="경고삭제")
    @commands.has_permissions(administrator=True)
    async def unwarn(self,ctx,user:discord.Member,ID,*,reason="사유없음"):
        a = db.getDb(os.getenv("DB_LOCATION"))
        try:
            data = a.getBy({"id":int(ID)})
            if data[0]["user_id"] != user.id:
                return await ctx.reply("해당 ID의 데이터가 없습니다.")
            count = a.getBy({"user_id": user.id})
            num = 0
            for i in count:
                num += 1
            a.deleteById(ID)
            em = discord.Embed(title=f"🚨 경고 취소 🚨", colour=discord.Colour.red())
            em.add_field(name="👮‍♂️경고 취소 요청자", value=f"{ctx.author.mention}", inline=False)
            em.add_field(name="📌경고 취소 대상자", value=f"{user.mention}", inline=False)
            em.add_field(name="경고 횟수", value=f"`{num}` 회")
            em.add_field(name="사유", value=f"~~{data[0]['reason']}~~\n\n{reason}", inline=False)
            em.set_footer(text=f"경고삭제ID - {ID}", icon_url=user.avatar_url)
            await ctx.reply(embed=em)
        except:
            await ctx.send("error")

    @commands.command(name="경고보기")
    async def show_warn(self,ctx,user:discord.Member=None):
        a = db.getDb(os.getenv("DB_LOCATION"))
        if user == None:
            em = discord.Embed(title=f"🚨 {ctx.author.display_name}님의 경고 로그 🚨", colour=discord.Colour.red())
            num = 0
            try:
                datas = a.getBy({"user_id": ctx.author.id})
                print(datas)
                for i in datas:
                    num += 1
                    em.add_field(name=f"경고ID - {i['id']}",value=f"< 사유 >\n{i['reason']}",inline=False)
            except:
                em.add_field(name="깨끗한 유저", value="지금까지 받은 경고 내역이 없습니다.")
            finally:
                em.add_field(name="깨끗한 유저", value="지금까지 받은 경고 내역이 없습니다.")
            em.set_footer(text=f"총 경고횟수: {num}", icon_url=ctx.author.avatar_url)
            await ctx.reply(embed=em)
        else:
            em = discord.Embed(title=f"🚨 {user.display_name}님의 경고 로그 🚨", colour=discord.Colour.red())
            num = 0
            try:
                datas = a.getBy({"user_id": user.id})
                print(datas)
                for i in datas:
                    num += 1
                    em.add_field(name=f"경고ID - {i['id']}", value=f"< 사유 >\n{i['reason']}", inline=False)
            except:
                em.add_field(name="깨끗한 유저", value="지금까지 받은 경고 내역이 없습니다.")
            finally:
                em.add_field(name="깨끗한 유저", value="지금까지 받은 경고 내역이 없습니다.")
            em.set_footer(text=f"총 경고횟수: {num}", icon_url=ctx.author.avatar_url)
            await ctx.reply(embed=em)

    @commands.command(name="뮤트")
    @commands.has_permissions(administrator=True)
    async def mute(self, ctx, member: discord.Member, *, reason="사유없음"):
        guild = ctx.guild
        mutedRole = discord.utils.get(guild.roles, name="Muted")

        if not mutedRole:
            mutedRole = await guild.create_role(name="Muted")
            channels = guild.channels
            for channel in channels:
                await channel.set_permissions(mutedRole, speak=False, send_messages=False)

        await member.add_roles(mutedRole, reason=reason)
        await ctx.send(f"{member.mention}님을 뮤트하였습니다.\n이유 : {reason}")
        await member.send(f"{guild.name} 에서 뮤트되셨습니다.")

    @commands.command(name="언뮤트")
    @commands.has_permissions(administrator=True)
    async def unmute(self, ctx, member: discord.Member):
        guild = ctx.guild
        mutedRole = discord.utils.get(guild.roles, name="Muted")

        await member.remove_roles(mutedRole)
        await ctx.send(f"{member.mention}님을 언뮤트하였습니다.")
        await member.send(f"{guild.name} 에서 언뮤트되셨습니다.")


def setup(bot):
    bot.add_cog(admin(bot))
    print('cogs - `admin` is loaded')