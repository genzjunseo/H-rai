import DiscordUtils
import discord
from discord.ext import commands
class etc(commands.Cog):
    def __init__(self,bot):
        self.bot = bot

    @commands.command(name="도움")
    async def helps(self, ctx: discord.Message):
        embed1 = discord.Embed(title="메인 페이지",
                               description="""
목차
(모든 커맨드의 필수요소는 ' * '로 표시하며 선택적요소는 ' () '로 표시합니다. 
실사용시 표시된 모든 기호는 제외하여 사용해주세요.)

• 1페이지: (현재페이지) 메인 페이지
• 2페이지: 서버관리
""",
                               color=ctx.author.color)
        embed1.set_footer(text='1 / 2', icon_url=ctx.author.avatar_url)

        embed2 = discord.Embed(title="서버관리", color=ctx.author.color)
        embed2.add_field(name="!경고 + @유저* + (사유)",
                         value="대상유저에세 경고를 부여합니다.",
                         inline=False)
        embed2.add_field(name="!경고삭제 + @유저* + 경고아이디* +(사유)",
                         value="대상유저에게 부여된 경고를 취소합니다.",
                         inline=False)
        embed2.add_field(name="!경고보기 + (@유저)",
                         value="대상유저 또는 자신에게 부여된 경고내역을 보여줍니다.",
                         inline=False)
        embed2.add_field(name="!뮤트 + @유저* + (사유)",
                         value="대상유저를 뮤트합니다.",
                         inline=False)
        embed2.add_field(name="!언뮤트 + @유저*",
                         value="대상유저를 언뮤트합니다.",
                         inline=False)
        embed2.set_footer(text='2 / 2', icon_url=ctx.author.avatar_url)


        paginator = DiscordUtils.Pagination.AutoEmbedPaginator(ctx)
        embeds = [embed1, embed2]
        await paginator.run(embeds)

def setup(bot):
    bot.add_cog(etc(bot))
    print('cogs - `etc` is loaded')